import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase


class Catalog(SqlAlchemyBase):
    __tablename__ = 'catalog'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    catalog = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    film = orm.relation("Film", back_populates='catalog')

    def __repr__(self):
        return f'<Profile>  {self.id} {self.genre}'