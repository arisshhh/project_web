from flask_wtf import FlaskForm
from wtforms import SubmitField, StringField, IntegerField, TextAreaField
from wtforms.validators import DataRequired


class AddFilmForm(FlaskForm):
    film_name = StringField('Название', validators=[DataRequired()])
    rating = IntegerField('Рейтинг', validators=[DataRequired()])
    genre = StringField('Жанры', validators=[DataRequired()])
    id_catalog = IntegerField('Id в каталоге (1-фильм, 2-сериал)', validators=[DataRequired()])
    duration = IntegerField('Продолжительность', validators=[DataRequired()])
    year_of_publication = IntegerField('Год выхода', validators=[DataRequired()])
    content = TextAreaField("Содержание", validators=[DataRequired()])
    img_film = StringField('Название файла', validators=[DataRequired()])

    submit = SubmitField('Сохранить')