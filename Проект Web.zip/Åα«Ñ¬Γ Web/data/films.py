import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Film(SqlAlchemyBase):
    __tablename__ = 'films'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    film_name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    rating = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    genre = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    id_catalog = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("catalog.id"))
    catalog = orm.relation('Catalog')
    duration = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    year_of_publication = sqlalchemy.Column(sqlalchemy.Integer, nullable=True, default=0)
    content = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    img_film = sqlalchemy.Column(sqlalchemy.String, nullable=True)

    def __repr__(self):
        return f'<Film> {self.id} {self.film_name}'
